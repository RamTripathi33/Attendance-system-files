#ifndef CREDITS_H
#define CREDITS_H

#define DEFAULT_WIFI_SSID "circuitdigest"  // default WiFi ssid
#define DEFAULT_WIFI_PASS "circuitdigest"  //default WiFi password
#define DEFAULT_mdns "biometric"           //default WiFi mdns adress , you can acess the web portal at http://biometric.local
#define DEFAULT_displayname "Semicon Media Pvt Ltd" //default Organization name which will be displayed on the OLED
#define DEFAULT_wwwusername "admin"        //default Login id
#define DEFAULT_wwwpassword "admin"        //default Login password

#endif
